DROP TABLE "public"."tracker_category_apps";
