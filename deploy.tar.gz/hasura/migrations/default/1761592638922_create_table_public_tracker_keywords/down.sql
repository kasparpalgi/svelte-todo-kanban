DROP TABLE "public"."tracker_keywords";
