alter table "public"."todos" alter column "list_id" set not null;
