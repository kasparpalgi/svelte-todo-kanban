CREATE OR REPLACE TRIGGER set_todo_alias_trigger
BEFORE INSERT ON todos
FOR EACH ROW
WHEN (NEW.alias IS NULL)
EXECUTE FUNCTION set_todo_alias();
