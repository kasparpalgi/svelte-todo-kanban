alter table "public"."todos" alter column "alias" set not null;
