alter table "public"."users" alter column "settings" drop not null;
