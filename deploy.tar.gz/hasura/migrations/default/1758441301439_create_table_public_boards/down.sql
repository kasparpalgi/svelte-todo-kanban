DROP TABLE "public"."boards";
