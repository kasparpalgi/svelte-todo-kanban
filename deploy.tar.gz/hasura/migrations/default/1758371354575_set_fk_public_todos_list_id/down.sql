alter table "public"."todos" drop constraint "todos_list_id_fkey";
