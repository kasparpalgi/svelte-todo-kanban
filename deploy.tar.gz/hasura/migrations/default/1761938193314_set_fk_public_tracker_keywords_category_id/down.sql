alter table "public"."tracker_keywords" drop constraint "tracker_keywords_category_id_fkey";
