alter table "public"."todos" add column "has_time" boolean not null default false;
