alter table "public"."todos" add column "min_hours" numeric
 null;
