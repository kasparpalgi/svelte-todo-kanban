alter table "public"."tracker_keywords" add column "category_id" uuid
 null;
