DROP TABLE "public"."tracker_categories";
