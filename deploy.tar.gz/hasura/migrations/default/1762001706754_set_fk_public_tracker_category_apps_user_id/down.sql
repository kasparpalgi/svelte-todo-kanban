alter table "public"."tracker_category_apps" drop constraint "tracker_category_apps_user_id_fkey";
