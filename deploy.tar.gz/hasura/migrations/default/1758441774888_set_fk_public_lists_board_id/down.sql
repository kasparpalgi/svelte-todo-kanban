alter table "public"."lists" drop constraint "lists_board_id_fkey";
