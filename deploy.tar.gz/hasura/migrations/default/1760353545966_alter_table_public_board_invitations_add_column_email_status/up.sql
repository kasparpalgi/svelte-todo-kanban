alter table "public"."board_invitations" add column "email_status" text
 null;
