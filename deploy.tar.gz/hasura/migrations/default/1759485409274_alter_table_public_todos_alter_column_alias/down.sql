alter table "public"."todos" alter column "alias" drop not null;
