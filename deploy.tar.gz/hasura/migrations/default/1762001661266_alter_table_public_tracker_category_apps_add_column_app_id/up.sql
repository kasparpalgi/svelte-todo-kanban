alter table "public"."tracker_category_apps" add column "app_id" integer
 not null;
