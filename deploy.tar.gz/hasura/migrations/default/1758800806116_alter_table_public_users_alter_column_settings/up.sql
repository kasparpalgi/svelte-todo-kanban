alter table "public"."users" alter column "settings" set not null;
