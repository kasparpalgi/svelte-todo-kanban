-- Revert cleanup_old_logs function
DROP FUNCTION IF EXISTS cleanup_old_logs(INT);
