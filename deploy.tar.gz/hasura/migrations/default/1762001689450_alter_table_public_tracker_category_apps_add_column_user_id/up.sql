alter table "public"."tracker_category_apps" add column "user_id" uuid
 null;
