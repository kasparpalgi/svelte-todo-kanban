alter table "public"."uploads" drop constraint "uploads_todo_id_fkey";
