alter table "public"."todos" add column "due_on" timestamptz
 null;
