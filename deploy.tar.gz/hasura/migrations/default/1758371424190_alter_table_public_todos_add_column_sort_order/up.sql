alter table "public"."todos" add column "sort_order" integer
 not null default '1';
