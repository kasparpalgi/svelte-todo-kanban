alter table "public"."boards" drop constraint "boards_user_id_fkey";
