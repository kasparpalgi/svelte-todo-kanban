alter table "public"."users" add column "dark_mode" boolean
 null default 'true';
