-- Drop activity_logs table
DROP TABLE IF EXISTS activity_logs;
