alter table "public"."boards" add column "alias" text
 null;
