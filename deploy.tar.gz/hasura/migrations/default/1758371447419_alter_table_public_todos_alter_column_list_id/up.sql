alter table "public"."todos" alter column "list_id" drop not null;
