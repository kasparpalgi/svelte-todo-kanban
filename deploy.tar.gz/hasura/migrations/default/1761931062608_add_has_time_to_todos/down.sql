alter table "public"."todos" drop column "has_time";
