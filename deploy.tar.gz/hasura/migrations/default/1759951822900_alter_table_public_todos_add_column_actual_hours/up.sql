alter table "public"."todos" add column "actual_hours" numeric
 null;
