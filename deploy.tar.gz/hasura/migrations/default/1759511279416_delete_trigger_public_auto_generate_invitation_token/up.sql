DROP TRIGGER "auto_generate_invitation_token" ON "public"."board_invitations";
