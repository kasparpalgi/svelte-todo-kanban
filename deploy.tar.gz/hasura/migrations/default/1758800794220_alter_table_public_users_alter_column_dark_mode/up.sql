alter table "public"."users" alter column "dark_mode" set not null;
