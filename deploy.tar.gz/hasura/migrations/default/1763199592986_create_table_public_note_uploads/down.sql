DROP TABLE IF EXISTS "public"."note_uploads";
