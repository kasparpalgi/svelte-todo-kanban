alter table "public"."tracker_category_apps" add column "app_id" uuid
 not null;
