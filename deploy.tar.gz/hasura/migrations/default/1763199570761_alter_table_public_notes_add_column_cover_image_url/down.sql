ALTER TABLE "public"."notes" DROP COLUMN "cover_image_url";
