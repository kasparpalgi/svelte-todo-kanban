alter table "public"."tracker_keywords" alter column "board_id" set not null;
