DROP TABLE "public"."uploads";
