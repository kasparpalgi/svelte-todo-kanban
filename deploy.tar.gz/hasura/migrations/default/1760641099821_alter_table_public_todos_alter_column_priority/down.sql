alter table "public"."todos" alter column "priority" set not null;
