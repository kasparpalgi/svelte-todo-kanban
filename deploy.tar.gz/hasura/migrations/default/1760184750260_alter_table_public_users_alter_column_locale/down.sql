alter table "public"."users" alter column "locale" set default 'en'::character varying;
