alter table "public"."todos" drop constraint "priority";
