alter table "public"."users" alter column "dark_mode" drop not null;
