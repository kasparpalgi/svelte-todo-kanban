export interface GetUserResult {
	users_by_pk?: {
		id: string;
		settings?: any;
	};
}