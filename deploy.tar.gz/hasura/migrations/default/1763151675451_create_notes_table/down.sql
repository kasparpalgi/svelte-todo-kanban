DROP TABLE IF EXISTS "public"."notes" CASCADE;
