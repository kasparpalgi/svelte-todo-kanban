CREATE INDEX IF NOT EXISTS idx_tracker_apps_user_id ON tracker_apps(user_id);
CREATE INDEX IF NOT EXISTS idx_tracker_sessions_user_id ON tracker_sessions(user_id);
