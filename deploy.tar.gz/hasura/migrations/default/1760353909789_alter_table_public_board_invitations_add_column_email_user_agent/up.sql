alter table "public"."board_invitations" add column "email_user_agent" text
 null;
