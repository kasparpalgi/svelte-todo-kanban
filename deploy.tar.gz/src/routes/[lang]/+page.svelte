<script>
	import { Loader } from 'lucide-svelte';
</script>

<Loader />
