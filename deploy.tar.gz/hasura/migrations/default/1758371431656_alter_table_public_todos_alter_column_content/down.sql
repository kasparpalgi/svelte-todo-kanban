alter table "public"."todos" alter column "content" set not null;
