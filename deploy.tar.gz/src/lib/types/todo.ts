import type { TodoFieldsFragment } from '$lib/graphql/generated/graphql';
import type { TodoImage } from './imageUpload';

export type Priority = 'low' | 'medium' | 'high';

export interface TodosState {
	todos: TodoFieldsFragment[];
	loading: boolean;
	error: string | null;
	initialized: boolean;
	currentBoardId: string | null;
}

export interface StoreResult<T = any> {
	success: boolean;
	message: string;
	data?: T;
}

export interface CanbanColumnProps {
	list: {
		id: string;
		name: string;
		sort_order: number;
		board?: {
			id: string;
			name: string;
			alias: string;
			sort_order: number;
			github?: string | null;
		} | null;
	};
	todos: TodoFieldsFragment[];
	isHighlighted?: boolean;
}

export interface TodoItemProps {
	todo: TodoFieldsFragment;
	draggedTodo: TodoFieldsFragment | null;
	isDragging?: boolean;
	showDropAbove?: boolean;
	listId: string;
	onDragStart: (todo: TodoFieldsFragment) => void;
	onDragEnd: () => void;
	onDelete: (todoId: string) => void;
}

export interface TodoEditProps {
	todo: TodoFieldsFragment;
	editData: any;
	validationErrors: Record<string, string>;
	images: TodoImage[];
	isDragOver: boolean;
	isSubmitting: boolean;
	onSave: () => Promise<void>;
	onCancel: () => void;
	onKeydown: (event: KeyboardEvent) => void;
	onDragOver: (event: DragEvent) => void;
	onDragLeave: (event: DragEvent) => void;
	onDrop: (event: DragEvent) => void;
	onFileSelect: (event: Event) => void;
	onRemoveImage: (id: string) => void;
	fileInput: HTMLInputElement | undefined;
}

export type CardDetailViewProps = {
	todo: TodoFieldsFragment;
	lang: string;
	onClose: () => void;
};

export type DragHandleProps = {
	attributes: Record<string, any>;
	listeners: Record<string, any>;
	isVisible?: boolean;
};

export type KanbanColumnProps = {
	list: { id: string; name: string; board?: { github?: string } };
	todos: TodoFieldsFragment[];
	draggedTodo: TodoFieldsFragment | null;
	dropTarget: {
		listId: string;
		index: number;
		position: 'above' | 'below';
	} | null;
	onDragStart: (todo: TodoFieldsFragment) => void;
	onDragEnd: () => void;
	onDelete: (todoId: string) => void;
};

// Store results

export interface TodoStoreResult {
	success: boolean;
	message: string;
	data?: TodoFieldsFragment;
}

export interface GenericStoreResult {
	success: boolean;
	message: string;
}

export interface LabelManagementProps {
	todo: TodoFieldsFragment;
}

export interface CardImageProps {
	todoId: string;
	initialImages?: TodoImage[];
}
