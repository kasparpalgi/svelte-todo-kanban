alter table "public"."lists" drop column "user_id" cascade;
