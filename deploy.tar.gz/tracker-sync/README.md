# Tracker integration

## Authentication

User downloads the app with JWT token generated inside the app.

## Sync

Tracker creates records to local text files and when from settings the records created by the tracker are periodically (every 10min or similar?) synced to the database. By now it will be the single central database hosted by us but user can deploy own database in own server (in future) to keep everything private.

## Installation

### Windows

#### Simple

Download exe and run it. Instructions to make it run when PC starts.

#### Advanced

Download exe that is installer. Minimum amount of "NEXT" button clicks and it is installed and runs in the background. Will start when system starts.

### Mac

? 

AI do it:D No, I mean. Sebi, do it!