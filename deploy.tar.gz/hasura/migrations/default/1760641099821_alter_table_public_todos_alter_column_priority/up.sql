alter table "public"."todos" alter column "priority" drop not null;
