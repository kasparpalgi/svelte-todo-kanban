ALTER TABLE users ADD COLUMN default_labels JSONB DEFAULT '[]';
