alter table "public"."users" alter column "locale" set not null;
