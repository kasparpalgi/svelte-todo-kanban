ALTER TABLE "public"."notes" ADD COLUMN "cover_image_url" text;
