alter table "public"."todos" add column "max_hours" numeric
 null;
