alter table "public"."board_invitations" add column "email_browser" text
 null;
