alter table "public"."tracker_categories" drop constraint "tracker_categories_user_id_fkey";
