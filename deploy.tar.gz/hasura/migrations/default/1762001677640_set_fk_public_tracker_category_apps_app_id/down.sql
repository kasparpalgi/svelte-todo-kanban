alter table "public"."tracker_category_apps" drop constraint "tracker_category_apps_app_id_fkey";
