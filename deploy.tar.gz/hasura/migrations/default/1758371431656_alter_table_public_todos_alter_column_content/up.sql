alter table "public"."todos" alter column "content" drop not null;
