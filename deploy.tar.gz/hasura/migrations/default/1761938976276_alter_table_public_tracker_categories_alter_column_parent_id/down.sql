alter table "public"."tracker_categories" alter column "parent_id" set not null;
