alter table "public"."tracker_category_apps" drop column "app_id" cascade;
