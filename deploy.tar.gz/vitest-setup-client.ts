/** @file vitest-setup-client.ts */
/// <reference types="@vitest/browser/matchers" />
/// <reference types="@vitest/browser/providers/playwright" />

import 'vitest-browser-svelte';