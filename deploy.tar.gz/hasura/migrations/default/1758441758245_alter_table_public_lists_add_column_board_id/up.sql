alter table "public"."lists" add column "board_id" uuid
 null;
