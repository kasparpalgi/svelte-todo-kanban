ALTER TABLE board_invitations
  ALTER COLUMN token SET NOT NULL;