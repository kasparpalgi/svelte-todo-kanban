alter table "public"."boards" add column "github" text
 null;
