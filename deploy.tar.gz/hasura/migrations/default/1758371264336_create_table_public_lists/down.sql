DROP TABLE "public"."lists";
