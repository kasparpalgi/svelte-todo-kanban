alter table "public"."todos" add column "comment_hours" text
 null;
