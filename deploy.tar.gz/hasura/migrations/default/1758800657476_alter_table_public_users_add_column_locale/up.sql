alter table "public"."users" add column "locale" varchar
 null default 'en';
