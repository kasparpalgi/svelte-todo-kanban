alter table "public"."users" alter column "locale" set default 'et'::character varying;
