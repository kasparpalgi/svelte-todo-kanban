-- Drop logs table and all dependent objects
DROP TABLE IF EXISTS logs CASCADE;
