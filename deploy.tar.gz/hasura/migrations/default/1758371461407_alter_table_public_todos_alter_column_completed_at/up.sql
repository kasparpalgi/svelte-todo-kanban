alter table "public"."todos" alter column "completed_at" drop not null;
