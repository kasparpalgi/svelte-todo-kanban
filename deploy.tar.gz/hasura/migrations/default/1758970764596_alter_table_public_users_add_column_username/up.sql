alter table "public"."users" add column "username" text
 null;
