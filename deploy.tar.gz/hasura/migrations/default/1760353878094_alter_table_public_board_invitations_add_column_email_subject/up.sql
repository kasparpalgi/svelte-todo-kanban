alter table "public"."board_invitations" add column "email_subject" text
 null;
