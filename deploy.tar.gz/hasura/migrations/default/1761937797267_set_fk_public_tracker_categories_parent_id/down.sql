alter table "public"."tracker_categories" drop constraint "tracker_categories_parent_id_fkey";
