export const languages = [
	{ value: 'en', label: 'English' },
	{ value: 'cs', label: 'Čeština' },
	{ value: 'et', label: 'Eesti' }
];