alter table "public"."todos" add column "priority" varchar
 null default 'medium';
