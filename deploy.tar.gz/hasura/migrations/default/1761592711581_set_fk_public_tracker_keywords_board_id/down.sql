alter table "public"."tracker_keywords" drop constraint "tracker_keywords_board_id_fkey";
