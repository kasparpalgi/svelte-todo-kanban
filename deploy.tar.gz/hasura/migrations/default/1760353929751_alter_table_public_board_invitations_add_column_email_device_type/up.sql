alter table "public"."board_invitations" add column "email_device_type" text
 null;
